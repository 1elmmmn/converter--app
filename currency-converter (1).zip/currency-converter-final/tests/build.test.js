const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { build } = require('../build.js');

const built = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');

test('index.html самодостаточен: нет ссылок на css/ и js/', () => {
  assert.doesNotMatch(built, /(?:href|src)="(?:css|js)\//);
  assert.match(built, /<style>/);
  assert.match(built, /<script>/);
});

test('index.html актуален: совпадает с результатом сборки из src/', () => {
  assert.equal(built, build(), 'Запустите: node build.js');
});
