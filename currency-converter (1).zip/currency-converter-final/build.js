#!/usr/bin/env node
/**
 * Сборка: src/index.html + src/css + src/js -> index.html в корне проекта.
 *
 * Готовый index.html самодостаточен: стили и скрипты лежат внутри него,
 * поэтому он открывается двойным кликом, из архива и на GitHub Pages
 * без каких-либо соседних файлов.
 *
 *   node build.js
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');

const SRC = path.join(__dirname, 'src');
const OUT = path.join(__dirname, 'index.html');

const read = (rel) => fs.readFileSync(path.join(SRC, rel), 'utf8');

function build() {
  let html = read('index.html');

  // функции вместо строк: в коде встречается «$», и replace трактовал бы его как шаблон
  html = html.replace('<link rel="stylesheet" href="css/style.css">', () => '<style>\n' + read('css/style.css').trimEnd() + '\n  </style>');

  const scripts = ['js/converter.js', 'js/app.js'];
  const tags = scripts.map((s) => `<script src="${s}"></script>`);
  if (!tags.every((t) => html.includes(t))) throw new Error('В src/index.html не найдены теги скриптов');

  const inline = scripts.map((s) => read(s).trimEnd().replace(/<\/script>/gi, '<\\/script>')).join('\n\n');
  html = html.replace(tags[0], () => '<script>\n' + inline + '\n  </script>');
  html = html.replace('\n  ' + tags[1], () => '');

  const left = html.match(/(?:href|src)="(?:css|js)\//g);
  if (left) throw new Error('В сборке остались ссылки на внешние файлы проекта: ' + left.join(', '));
  return html;
}

module.exports = { build };

if (require.main === module) {
  fs.writeFileSync(OUT, build());
  console.log('Готово: index.html (' + fs.statSync(OUT).size + ' байт)');
}
